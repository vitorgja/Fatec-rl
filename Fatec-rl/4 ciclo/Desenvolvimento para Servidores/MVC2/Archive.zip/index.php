<?
	require_once "library/url.php";
	redirect("home/");
?>