<?php
	$config['base_url'] = 'http://webfatec.esy.es/FATEC/4ciclo/servidores1-PHP/MVC2/';
?>