<form action="<?= base_url('home/auth/');?>" method="POST">
	Login:<input type="text" name="lo"><br>
	Senha:<input type="password" name="se"><br>
	<input type="submit" value="vai">
</form>