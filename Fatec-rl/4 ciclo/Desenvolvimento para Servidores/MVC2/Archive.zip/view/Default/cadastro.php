<main>
	<h1>Cadastro</h1>
	<form action="http://webfatec.esy.es/FATEC/4ciclo/servidores1-PHP/MVC2/cad/" method="POST">
		Nome:<input type="text" name="no"><br>
		Login:<input type="text" name="lo"><br>
		Senha:<input type="password" name="se"><br>
		<input type="submit" value="vai">
	</form>
</main>