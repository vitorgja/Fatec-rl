
		<footer>
			<div>footer</div>
		</footer>
	</body>
</html>