<html>
	<meta charset="UTF-8">
	<body>
		<main>
			<h1>Error 404</h1>
			<p>
				Este erro e proveniente de URL incorreta ou a página excluida de nosso Servidor.
				<span>Desculpe o Transtorno</span>
			</p>
			<p>
				<a href="<?= base_url("home/")?>">ir para a Home</a>
			</p>
		</main>
	</body>
</html>