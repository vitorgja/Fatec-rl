<!-- SESSÃO CONTENT (CONTEUDO) -->
	<main id="conteudo">

		<div class="container">
			<div class="page-header">
				<h1>Empresa</h1>
			</div>

			<h3>Sobre a Higuer</h3>


			<img class="passageiros" src="<?= base_url("view/".$this->tema."/")?>image/passageiros.jpg" alt="">
			<p>
				Nosso objetivo é simples, ajudar as pessoas a comprar passagens aéreas mais baratas.
			</p>


			<p>
		 		No higher.com.br você encontra passagens em promoção para destinos em todo o mundo. 
				Planeje aquela viagem tão desejada. Seja voando para o Rio de Janeiro, São Paulo, Salvador, 
				Fortaleza ou qualquer destino pelo Brasil e por todos os continentes, sempre com o melhor preço.
			</p>
			<p>
				Realize sua viagem com a gente e tenha sempre uma opção em passagens promocionais. 
				Aqui você conseguirá acordos exclusivos feitos com diversas linhas aéreas e poderá 
				comprar sua passagem com toda a comodidade que a higher pode oferecer. Em um só lugar, 
				companhias aéreas de todo o mundo, alertas de promoções próximas a data da sua viagem, 
				ótimos preços e parcelamento sem juros no cartão de crédito!
			<p>
				Atenciosamente,<br>Equipe da Higuer.
			</p>
			<br class="clearfix">
		</div><!-- fecha class container -->
	</main><!-- fecha id #conteudo -->