<!-- SESSÃO CONTENT (CONTEUDO) -->
	<main id="conteudo">

		<div class="container">
			<div class="page-header">
				<h1>ERROR 404</h1>
			</div>

			<h3>Pagina não encontrada</h3>


			<p>
				Sentimos muito porem a pagina nao foi encontrada em nosso Site.
			</p>


			<p>
		 		Alguns motivos podem ter levado a esse erro, um deles pode ser o link, verifique-o e tente novamente, 
				se você navegou alterando a URL e capas de ter se enganado quanto a URL desejada, ou talves a página que 
				tentou acessar foi descontinuada em nosso site.
			</p>
			<p>
				Caso o problema persista entre em contato com nossa equipe, que resolveremos o seu problema de acesso ao site.
			<p>
				Atenciosamente,<br>Equipe da Higuer.
			</p>
			<br class="clearfix">
		</div><!-- fecha class container -->
	</main><!-- fecha id #conteudo -->