	<!-- SESSÃO FOOTER (RODAPE) -->
	<footer id="footer">
		<div class="container">
			<div class="text-center"> 		
				<img src="<?= base_url("view/".$this->tema."/")?>image/rodapé.jpg" alt="">
				<p class="text-muted">
				Copyright © 2000 - 2013 www.higuer.com.br, TODOS OS DIREITOS RESERVADOS. As fotos, imagens, logotipos, marca, conjunto imagem, layout e trade dress aqui veiculados são de propriedade exclusiva. É vedada qualquer reprodução, total ou parcial, de qualquer elemento de identidade, sem expressa autorização. 
				</p>
			</div>
		</div>
	</footer>





</body>
</html>