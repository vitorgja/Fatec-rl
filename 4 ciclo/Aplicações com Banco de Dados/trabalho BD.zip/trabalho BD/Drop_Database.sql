use TrabalhoBD
go

--Deletar todos os Registros de Todas as Tabelas
DELETE FROM Ordem_compra_has_Peca
DELETE FROM Ordem_compra
DELETE FROM Fornecedor
DELETE FROM Peca_has_Pedido
DELETE FROM Pedido
DELETE FROM Peca
DELETE FROM Receptaculo
DELETE FROM Cliente

drop table Ordem_compra_has_Peca
go 
drop table Ordem_compra
go
drop table Fornecedor 
go
drop table Peca_has_Pedido 
go
drop table Pedido
go

drop table Receptaculo 
go
drop table Cliente 
go

drop table Peca
go

use master
drop database TrabalhoBD