<html>
	<head>
	</head>
	<body>
		<h1>Resultado</h1>
		<h2><?= $data['fibonacci']?></h2>
	</body>
</html>