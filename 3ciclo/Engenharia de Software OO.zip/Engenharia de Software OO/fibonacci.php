<?php

class Fibonacci{

	public function fib($n){
		if($n == 1 || $n == 2){
			return 1;
		}else{
			$aux = $this->fib($n-1)+$this->fib($n-2);
			return $aux;
		}
	}


}
$n1 = isset($_GET['n1'])? $_GET['n1'] : 1;

$f = new Fibonacci();
echo $f->fib($n1);
//echo $f->getHistorico();



?>


<form action="#" method="get">
	Numero: <input type="text" name="n1">
	<input type="submit" value=" vai la ver">
</form>