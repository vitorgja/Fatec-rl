<!DOCTYPE HTML>
 <html lang="pt-br">
	<head>
		<meta charset="utf-8"/>
		<title>Trabalho de Engenharia de Software - Dados Usuario Cadastrado</title>
		<link rel="stylesheet" href="view/css/layout.css">
		<script src="view/js/include/jquery-1.11.3.js"></script>
		<script src="view/js/script.js"></script>
	</head>
	<body>
		<header>
			<div>
				<h1>Trabalho de Orientação a Objeto</h1>
			</div>
		</header>
		<main>
			<div>
				<h2>Dados do Usuário Cadastrado</h2>
				
				<p>
					Nome: <?= $data['nome']?>
					Sexo:<?= $data['sexo']?>
					Idade:<?= $data['idade']?>
					Salario:<?= $data['salario']?>
					Profissao<?= $data['profissao']?>
				</p>
			</div>
		</main>
		<footer>
			<div>
				<h3>Integrantes</h3>
				<p>Andressa Miki | Diandra | Sandra | Victor | Vitor Pereira </p>	
			</div>
		</footer>
	</body>
</html>