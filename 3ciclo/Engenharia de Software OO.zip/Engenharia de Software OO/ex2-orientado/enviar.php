<?php

class Salvar{
	
	private $nome,$sexo,$salario,$idade,$profissao;

	public function __construct($nome,$sexo,$salario,$idade,$profissao){
		$this->nome = $nome;
		$this->sexo = $sexo;
		$this->salario = $salario;
		$this->idade = $idade;
		$this->profissao = $profissao;
	}

	public function mostrar(){
		$data['nome'] = $this->nome;
		$data['sexo'] = $this->sexo;
		$data['salario'] = $this->salario;
		$data['idade'] = $this->idade;
		$data['profissao'] = $this->profissao;
		require_once "view/mostrar.php";
	}

}
$nome = isset($_POST['nome']) ? $_POST['nome'] : "";
$sexo = isset($_POST['sexo']) ? $_POST['sexo'] : "";
$salario = isset($_POST['salario']) ? $_POST['salario'] : "";
$idade = isset($_POST['idade']) ? $_POST['idade'] : "";
$profissao = isset($_POST['profissao'])? $_POST['profissao'] : "";

$salvar = new Salvar($nome,$sexo,$salario,$idade,$profissao);
$salvar->mostrar();





?>