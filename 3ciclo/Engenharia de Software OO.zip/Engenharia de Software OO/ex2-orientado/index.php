<!DOCTYPE HTML>
 <html lang="pt-br">
	<head>
		<meta charset="utf-8"/>
		<title>Trabalho de Engenharia de Software - Formulário</title>
		<link rel="stylesheet" href="view/css/layout.css">
		<script src="view/js/include/jquery-1.11.3.js"></script>
		<script src="view/js/include/jquery.validate.js"></script>
		<script src="view/js/script.js"></script>
	</head>
	<body>
		<header>
			<div>
				<h1>Trabalho de Orientação a Objeto</h1>
			</div>
		</header>
		<main>
			<div>
				<!--  onsubmit="return verifica()" -->
				<form id="formulario" method="post" action="enviar.php">
					<label>Nome do candidato: <input type="text" name="nome"></label><br>
					<label>
						Sexo: 	<input type="radio" name="sexo" value="M"> Masculino - 
						<input type="radio" name="sexo" value="F"> Feminino		
					</label><br>
						<label>Pretensão salarial: <input type="text" name="salario"></label><br>
					<label>Idade: <input type="number" name="idade"></label><br>
					<label>Profissão: 
						<select name="profissao">
							<option></option>
							<option value="1">Cartógrafo</option>
							<option value="2">Assistente Social</option>
							<option value="3">Psicólogo</option>
							<option value="4">Atendente</option>
							<option value="5">Secretária Bilíngue</option>
							<option value="6">Geólogo</option>
						</select>
					</label><br><br>
					<input type="submit" value="Enviar" id="submit"> <input type="reset" value="Limpar">
				</form>
	 		</div>
		</main>
		<footer>
			<div>
				<h3>Integrantes</h3>
				<p>Andressa Miki | Diandra | Sandra | Victor | Vitor Pereira </p>	
			</div>
		</footer>
	</body>
</html>

